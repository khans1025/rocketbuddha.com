<?php
/*
  Plugin Name: Templatemela Product Quickview
  Plugin URI: http://www.templatemela.com
  Description: Templatemela Custom Shortcodes for templatemela wordpress themes.
  Version: 1.0
  Author: Templatemela
  Author URI: http://www.templatemela.com
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
add_action( 'woocommerce_before_shop_loop_item','wpb_wl_hook_quickview_link', 11 );
function wpb_wl_hook_quickview_link(){
	echo '<div class="wpb_wl_preview_area"><a class="wpb_wl_preview open-popup-link" href="#wpb_wl_quick_view_'.get_the_id().'" data-effect="mfp-zoom-in">'.__( 'Quick View','fashion-feast' ).'</a></div>';
}
add_action( 'woocommerce_after_shop_loop_item','wpb_wl_hook_quickview_content' );
function wpb_wl_hook_quickview_content(){
	global $post, $woocommerce, $product;
	?>
	<div id="wpb_wl_quick_view_<?php echo get_the_id(); ?>" class="mfp-hide mfp-with-anim wpb_wl_quick_view_content wpb_wl_clearfix">
		<div class="wpb_wl_images">
			<?php
				if ( has_post_thumbnail() ) {
				$image_title = esc_attr( get_the_title( get_post_thumbnail_id() ) );
				$image_link  = wp_get_attachment_url( get_post_thumbnail_id() );
				$image       = get_the_post_thumbnail( $post->ID, apply_filters( 'single_product_large_thumbnail_size', 'shop_single' ), array(
					'title' => $image_title
					) );
				$attachment_count = count( $product->get_gallery_attachment_ids() );
				if ( $attachment_count > 0 ) {
					$gallery = '[product-gallery]';
				} else {
					$gallery = '';
				}
				echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<a href="%s" class="woocommerce-main-image zoom" title="%s" data-rel="prettyPhoto' . $gallery . '">%s</a>', $image_link, $image_title, $image ), $post->ID );
				} else {
				echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" alt="%s" />', wc_placeholder_img_src(), __( 'Placeholder', 'fashion-feast' ) ), $post->ID );
				}
			?>
		</div>
		<div class="wpb_wl_summary">
			<!-- Product Title -->
			<h2 class="wpb_wl_product_title"><?php the_title();?></h2>			
			<!-- Product Rating -->
			<?php	if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' )
				return;
			?>			
			<?php if ( $rating_html = $product->get_rating_html() ) : ?>
			<?php echo $rating_html; ?>
			<?php endif; ?>			
			<!-- Product Price -->
			<?php if ( $price_html = $product->get_price_html() ) : ?>
				<span class="price wpb_wl_product_price"><?php echo $price_html; ?></span>
			<?php endif; ?>
			<!-- Product short description -->
			<?php woocommerce_template_single_excerpt();?>			
			<!-- Product cart link -->
			<?php woocommerce_template_single_add_to_cart();?>									
			<!-- Product SKU -->			
			<?php if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) : ?>
				<span class="sku_wrapper"><?php _e( 'SKU:', 'fashion-feast' ); ?> <span class="sku"><?php echo ( $sku = $product->get_sku() ) ? $sku : __( 'N/A', 'fashion-feast' ); ?></span>.</span>
			<?php endif; ?>
			<!-- Product Categories -->
			<?php $cat_count=""; echo $product->get_categories( ', ', '<span class="posted_in">' . _n( 'Category:', 'Categories:', $cat_count, 'fashion-feast' ) . ' ', '.</span>' ); ?>
		</div>
	</div>
	<?php
}
