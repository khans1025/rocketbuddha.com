<?php
/**
 * TemplateMela
 * @copyright  Copyright (c) TemplateMela. (http://www.templatemela.com)
 * @license    http://www.templatemela.com/license/
 * @author         TemplateMela
 * @version        Release: 1.0
 */
add_image_size('gallery-thumbnail', 145, 145, true);
if ( ! isset( $content_width ) )
	$content_width = 1150;
/**  Set Default options : Theme Settings  */
function tm_set_default_options()
{
	add_option("tmoption_logo_image", get_stylesheet_directory_uri()."/images/megnor/logo.png"); // set logo image	
	add_option("tmoption_logo_image_alt",'Fashion Feast'); // set logo image alt
	add_option("tmoption_showsite_description",'no'); // yes/no, control panel	
	add_option("tmoption_contact_email",'support@templatemela.com'); // yes/no, control panel
	add_option("tmoption_control_panel",'no'); // yes/no, control panel	
	add_option("tmoption_responsive",'yes'); // yes/no, responsive	
	add_option("tmoption_Socials_panel",'yes'); // yes/no, social panel
	add_option("tmoption_related_posts",'yes'); // yes/no, related posts
	add_option("tmoption_background_upload",""); // Default, texture specified image
	add_option("tmoption_texture",'body-bg.png'); // Default, extra texture image
	add_option("tmoption_back_repeat","repeat"); // background repeate
	add_option("tmoption_back_position","top+left"); // background position
	add_option("tmoption_back_attachment","scroll"); // background attachment
	add_option("tmoption_bkg_color","FFFFFF"); // background color
	add_option("tmoption_bodyfont_color","676767"); // body font color
	add_option("tmoption_bodyfont",'Roboto'); // Open Sans	
	add_option("tmoption_bodyfont_other",'Arial'); // Arial
	add_option("tmoption_Newsletter_title",'Sign Up For Newsletter'); // Newsletter title
	add_option("tmoption_button_color","EA4848"); // button color
	add_option("tmoption_button_hover_color","343434"); // button hover color
	add_option("tmoption_theme_color","EA4848"); // Theme common color
	
	/*  Top Bar Settings  */	
	add_option("tmoption_show_topbar","yes"); // show top bar
	add_option("tmoption_topbar_bkg_color","EFEFEF"); // topbar_bkg_color
	add_option("tmoption_topbar_text_color","9A9A9A"); // topbar_text_color
	add_option("tmoption_topbar_link_color","9A9A9A"); // topbar_link_color
	add_option("tmoption_topbar_link_hover_color","EA4848"); // topbar_link_hover_color
	add_option("tmoption_show_topbar_social","yes"); // show_topbar_social
	add_option("tmoption_topbar_twitter","#"); // topbar_twitter
	add_option("tmoption_topbar_facebook","#"); // topbar_facebook
	add_option("tmoption_topbar_google_plus","#"); // topbar_google_plus
	add_option("tmoption_topbar_linkedin","#"); // topbar_linkedin
	add_option("tmoption_topbar_youtube",""); // topbar_youtube
	add_option("tmoption_topbar_rss",""); // topbar_rss
	add_option("tmoption_topbar_pinterest",""); // topbar_pinterest
	add_option("tmoption_topbar_skype",""); // topbar_skype
	add_option("tmoption_show_topbar_callus","yes");
	add_option("tmoption_topbar_phone_text","Call :");	
	add_option("tmoption_topbar_phone","0123-456-789");
	
	
	/*add_option("tmoption_custom_banner","no"); // Show Custom Banner
	add_option("tmoption_custom_text1","Free Delivery Wordwide"); // Custom Text 1
	add_option("tmoption_custom_text1_desc","At vero eos et accusamus et iusto odio"); // Custom Text 1 desc
	add_option("tmoption_custom_text2","Free Return For 90 Days"); // Custom Text 2
	add_option("tmoption_custom_text2_desc","At vero eos et accusamus et iusto odio"); // Custom Text 2 desc
	add_option("tmoption_custom_text3","Discount On Order Gift"); // Custom Text 3	
	add_option("tmoption_custom_text3_desc","At vero eos et accusamus et iusto odio"); */// Custom Text 3 desc
	/*  Header Settings  */	
	add_option("tmoption_header_layout","2"); // header layout
	add_option("tmoption_header_back_repeat","repeat"); // header background repeate
	add_option("tmoption_header_back_position","top+left"); // header background position
	add_option("tmoption_header_back_attachment","scroll"); // header background attachment	
	add_option("tmoption_header_bkg_color","191919"); // header background color	
	add_option("tmoption_navfont",'Open+Sans'); // navigation menu font
	add_option("tmoption_navfont_other",'Arial'); // navigation menu specified font
	/*  Content Settings  */
	add_option("tmoption_h1font",'Roboto'); // h1 family google font
	add_option("tmoption_h1font_other",'Arial'); // h1 family specified font
	add_option("tmoption_h1color",'2C2F32'); // h1 family font color	 
	add_option("tmoption_h2font",'Roboto'); // h2 family google font
	add_option("tmoption_h2font_other",'Arial'); // h2 family specified font
	add_option("tmoption_h2color",'2C2F32'); // h2 family font color	
	add_option("tmoption_h3font",'Roboto'); // h3 family google font
	add_option("tmoption_h3font_other",'Arial'); // h3 family specified font
	add_option("tmoption_h3color",'2C2F32'); // h3 family font color	
	add_option("tmoption_h4font",'Open+Sans'); // h4 family google font
	add_option("tmoption_h4font_other",'Arial'); // h4 family specified font
	add_option("tmoption_h4color",'2C2F32'); // h4 family font color	
	add_option("tmoption_h5font",'Open+Sans'); // h5 family google font
	add_option("tmoption_h5font_other",'Arial'); // h5 family specified font 
	add_option("tmoption_h5color",'2C2F32'); // h5 family font color	
	add_option("tmoption_h6font",'Open+Sans'); // h6 family google font
	add_option("tmoption_h6font_other",'Arial'); // h6 family specified font 
	add_option("tmoption_h6color",'2C2F32'); // h6 family font color	
	add_option("tmoption_link_color","676767"); // link color
	add_option("tmoption_hoverlink_color","EA4848"); // link hovre color
	/*  Footer Settings  */	
	add_option("tmoption_footerbkg_color","2b2b2b"); // footer background color
	add_option("tmoption_footerlink_color","999999"); // footer link text color
	add_option("tmoption_footerhoverlink_color","EA4848"); // footer link hover text color
	add_option("tmoption_footerfont",'Open+Sans'); // footer google font
	add_option("tmoption_footerfont_other",'Arial'); // footer specified font
	add_option("tmoption_footer_slog",'Templatemela.'); // copyright statement : Theme By templatemela
	add_option("tmoption_footer_link",'https://www.templatemela.com'); // copyright statement : Theme By templatemela
	/*  Portfolio Settings  */
	/*add_option("tmoption_portfolio_cat","yes"); 
	add_option("tmoption_portfolio_layout","3"); 
	add_option("tmoption_portfolio_perpage","4"); 
	add_option("tmoption_h3font_other","Arial");
	add_option("tmoption_navigation_home_link",'yes'); // yes/no, categories, pages	
	add_option("tmoption_portfolio_cat",'yes'); // asc, desc
	add_option("tmoption_portfolio_layout",'One Column'); // one column, two column, three column, four column
	add_option("tmoption_portfolio_perpage",'6'); // by default 6
	add_option("tmoption_headerfont",'Open Sans');	*/
	/* Shop page settings */
	add_option("tmoption_myaccount_text","My Account"); 
	add_option("tmoption_register_text","Login / Register");
	add_option("tmoption_logout_text","Logout");
	add_option("tmoption_shop_items","9"); 
	add_option("tmoption_shop_items_per_row","3"); 
	add_option("tmoption_related_items","9"); 
	add_option("tmoption_related_items_per_row","3");
	add_option("tmoption_upsells_items","9"); 
	add_option("tmoption_upsells_items_per_row","3");	
	/* Slider settings */
	add_option("tmoption_slider_navigation","yes"); // displays slider navigation arrows
	add_option("tmoption_slider_pagination","yes"); // displays slider pagination
	add_option("tmoption_slide_animation_type","slide"); // slider pagination type image/bullet
	add_option("tmoption_slider_autoplay","yes"); // auto plays slider
	add_option("tmoption_slideshow_speed","7000"); // slider speed
	add_option("tmoption_animation_duration","600"); // slider duration
}
add_action('init', 'tm_set_default_options');
function tm_get_logo() {
	if (trim(get_option('tmoption_logo_image_alt')) != '') $logo_alt = get_option('tmoption_logo_image_alt') ; else $logo_alt = esc_attr(get_bloginfo('name', 'display' ));
	if (trim(get_option('tmoption_logo_image')) != ''){ echo '<img alt="'.get_option('tmoption_logo_image_alt').'" src="'.get_option('tmoption_logo_image').'" />';}
	           else{echo '<img alt="'.get_option('tmoption_logo_image_alt').'" src=" '.get_template_directory_uri(). '/images/megnor/logo.png">';}
}
function tm_get_sort_column() {
	$sort_column=''; 
	if(trim(get_option('tmoption_navigation_type'))=='categories'){
		if( trim(get_option('tmoption_navigation_sort_column')) =='id' || trim(get_option('tmoption_navigation_sort_column'))=='menu_order')
			$sort_column = 'ID';
		elseif(trim(get_option('tmoption_navigation_sort_column'))=='name' || trim(get_option('tmoption_navigation_sort_column'))=='post_title')
			$sort_column = 'name';
		elseif(trim(get_option('tmoption_navigation_sort_column'))=='count')
			$sort_column = 'count';
	}
	elseif(trim(get_option('tmoption_navigation_type'))=='pages'){
		if(trim(get_option('tmoption_navigation_sort_column'))=='id')
			$sort_column = 'ID';
		elseif(trim(get_option('tmoption_navigation_sort_column'))=='menu_order')
			$sort_column = 'menu_order';
		elseif(trim(get_option('tmoption_navigation_sort_column'))=='post_title' || trim(get_option('tmoption_navigation_sort_column'))=='name')
			$sort_column = 'post_title';
	}
	return $sort_column;
}
function tm_get_sort_order() {
	$sort_order='';
	if(trim(get_option('tmoption_navigation_sort_order'))=='asc')
		return 'asc';
	if(trim(get_option('tmoption_navigation_sort_order'))=='desc')
		return 'desc';
	return $sort_order;
}
function tm_get_all_categories() {
	global $wp_query; 
	if (isset($wp_query->post->ID)) $postid = $wp_query->post->ID; 
	$categories = wp_get_post_categories( $postid );
	$cats = ', ';
	foreach($categories as $c){
		$cat = get_category( $c );	
		$cats .= $cat->name. ',';
	}
	$cats=strtolower(rtrim($cats, " ,"));
	return $cats;
}
function tm_get_all_tags() {
	global $wp_query; 
	if (isset($wp_query->post->ID)) $postid = $wp_query->post->ID; 
	$alltags = wp_get_post_tags( $postid );
	$tags = ', ';
	foreach($alltags as $tag){
		$tags .= $tag->name. ',';
	}
	$tags=strtolower(rtrim($tags, " ,"));
	return $tags;
}
/*function extra_head(){
	$themeinfo = wp_get_theme(get_template_directory() . '/style.css');	
	echo '<meta name="generator" content="'.$themeinfo['Name'].' - '.$themeinfo['Version'].'" />';
}
add_action('wp_head','extra_head');
*///Load responsive.css file in the header
function tm_responsive()
{
if(get_option('tmoption_responsive') == 'yes'):
	wp_enqueue_style('responsive', get_stylesheet_directory_uri() . '/responsive.css');
endif;
}
add_action('wp_head','tm_responsive');
add_action( "admin_enqueue_scripts", 'templatemela_admin_scripts');
add_action( "admin_enqueue_scripts", 'templatemela_admin_styles');
add_action( "admin_enqueue_scripts", 'templatemela_admin_metabox_script');
add_action( "admin_enqueue_scripts", 'templatemela_admin_metabox_styles');
function templatemela_admin_scripts() {
	//Scripts	
	wp_enqueue_script( 'pscript_admin', get_template_directory_uri() . '/js/megnor/admin/pscript_admin.js');
	wp_enqueue_script( 'jscolor', get_template_directory_uri() . '/js/megnor/admin/jscolor/jscolor.js');
	wp_enqueue_script( 'jquery-easytabs-min', get_template_directory_uri() . '/js/megnor/admin/jquery.easytabs.min.js');
	wp_enqueue_script('media-upload');
	wp_enqueue_script('thickbox');
	wp_register_script('my-upload', get_template_directory_uri() . '/js/megnor/admin/custom.js', array('jquery','media-upload','thickbox'));
	wp_enqueue_script('my-upload');	
}
function templatemela_admin_styles() { 
	//Styles
	wp_enqueue_style('tm_admin', get_template_directory_uri() . '/css/megnor/admin/tm_admin.css');
	wp_enqueue_style('tab', get_template_directory_uri() . '/css/megnor/admin/tab.css');
	wp_enqueue_style('thickbox');
}
function templatemela_admin_metabox_script() { 
	//Scripts
	wp_enqueue_script( 'tm_metabox_script', get_template_directory_uri() . '/js/megnor/admin/tm_metabox_script.js' );
}
function templatemela_admin_metabox_styles() { 
	//Styles
	wp_enqueue_style('tm_metabox_style', get_template_directory_uri() . '/css/megnor/admin/tm_metabox_style.css');
}
/*function templatemela_info_page() {
	$locale_file = get_template_directory() . "/templatemela/admin/templatemela.php";
	if (is_readable( $locale_file ))
		get_template_part('templatemela/admin/templatemela');
}*/
function templatemela_theme_settings_page() {
	$locale_file = get_template_part('templatemela/admin/theme-setting');
	if (is_readable( $locale_file ))
		get_template_part( 'templatemela/admin/theme-setting');
}
function templatemela_hook_manage_page() {
	$locale_file = get_template_part('templatemela/admin/theme-hook') ;
	if (is_readable( $locale_file ))
		get_template_part('templatemela/admin/theme-setting');
}
function templatemela_add_admin_menu_separator($position) {
  global $menu;
  $index = 0;
  foreach($menu as $offset => $section) {
    if (substr($section[2],0,9)=='separator')
      $index++;
    if ($offset>=$position) {
      $menu[$position] = array('','read',"separator{$index}",'','wp-menu-separator');
      break;
    }
  }
  ksort($menu);
}
if ( ! function_exists( 'templatemela_admin_header_style' ) ) :
	function templatemela_admin_header_style() {}
endif;
/**
 * Sets the post excerpt length to 40 characters.
 * To override this length in a child theme, remove the filter and add your own
 * function tied to the excerpt_length filter hook.
 * @return int
 */
function templatemela_excerpt_length( $length ) {
	return 200;
}
remove_filter( 'excerpt_length', 'templatemela_excerpt_length' ); 
add_filter( 'excerpt_length', 'templatemela_excerpt_length' );
function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}
/**
 * Returns a "Continue Reading" link for excerpts
 * @return string "Continue Reading" link
 */
function templatemela_continue_reading_link() {
	return ' <a class="read-more-link" href="'. get_permalink() . '">' . __( 'Read More', 'fashion-feast' ) . '</a>';
}
add_filter( 'excerpt_length', 'templatemela_excerpt_length' );
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with an ellipsis and templatemela_continue_reading_link().
 * To override this in a child theme, remove the filter and add your own
 * function tied to the excerpt_more filter hook.
 * @return string An ellipsis
 */
function templatemela_auto_excerpt_more( $more ) {
	return  '&hellip;' .templatemela_continue_reading_link();
}
add_filter( 'excerpt_more', 'templatemela_auto_excerpt_more' );
/**
 * Adds a pretty "Continue Reading" link to custom post excerpts.
 * To override this link in a child theme, remove the filter and add your own
 * function tied to the get_the_excerpt filter hook.
 * @return string Excerpt with a pretty "Continue Reading" link
 */
function templatemela_custom_excerpt_more( $output ) {
	if ( has_excerpt() && ! is_attachment() ) {
		$output = '&hellip;'. templatemela_continue_reading_link();
	}
	return $output;
}
/**
 * Deprecated way to remove inline styles printed when the gallery shortcode is used.
 * This function is no longer needed or used. Use the use_default_gallery_style
 * filter instead, as seen above.
 * @deprecated Deprecated in TemplateMela for WordPress 3.1
 * @return string The gallery style filter, with the styles themselves removed.
 */
function templatemela_remove_gallery_css( $css ) {
	return preg_replace( "#<style type='text/css'>(.*?)</style>#s", '', $css );
}
// Backwards compatibility with WordPress 3.0.
if ( version_compare( $GLOBALS['wp_version'], '3.3.2', '<' ) )
	add_filter( 'gallery_style', 'templatemela_remove_gallery_css' );
/**
 * Return the URL for the first link found in the post content.
 *
 * @since Twenty Eleven 1.0
 * @return string|bool URL or false when no link is present.
 */
function templatemela_url_grabber() {
	if ( ! preg_match( '/<a\s[^>]*?href=[\'"](.+?)[\'"]/is', get_the_content(), $matches ) )
		return false;
	return esc_url_raw( $matches[1] );
}
function templatemela_get_widget($location = '') {
	if ( is_active_sidebar($location) ) { 
		dynamic_sidebar($location); 
	}
}
if (version_compare( $GLOBALS['wp_version'], '3.3', '>=' )) 
	get_template_part('templatemela/widgets');	
/**
 * Removes the default styles that are packaged with the Recent Comments widget.
 *
 * To override this in a child theme, remove the filter and optionally add your own
 * function tied to the widgets_init action hook.
 * This function uses a filter (show_recent_comments_widget_style) new in WordPress 3.1
 * to remove the default style. Using TemplateMela in WordPress 3.0 will show the styles,
 * but they won't have any effect on the widget in default TemplateMela styling.
 *
 */
function templatemela_remove_recent_comments_style() {
	add_filter( 'show_recent_comments_widget_style', '__return_false' );
}
add_action( 'widgets_init', 'templatemela_remove_recent_comments_style' );
function templatemela_get_pagination($range = 4){  
	// $paged - number of the current page  
	global $paged, $wp_query, $max_page;  
	// How much pages do we have?  
	if ( !$max_page ) {  
		$max_page = $wp_query->max_num_pages;  
	}  
	// We need the pagination only if there are more than 1 page  
	if($max_page > 1){  
		if(!$paged){  
			$paged = 1;  
		}  
		// On the first page, don't put the First page link  
		if($paged != 1){  
			echo '<a class="first" href=" '. get_pagenum_link(1) .' "> << </a>';  
		}
		// To the previous page  
		previous_posts_link(' < ');
		// We need the sliding effect only if there are more pages than is the sliding range  
		if($max_page > $range){  
		 // When closer to the beginning  
			 if($paged < $range){  
			   for($i = 1; $i <= ($range + 1); $i++){  
			   	 if($i==$paged){$class = "current number"; }else { $class = "number"; } 
				 echo "<a class='".$class."' href='" . get_pagenum_link($i). "'>$i</a>";  
			   }  
			 }  
			 // When closer to the end  
			 elseif($paged >= ($max_page - ceil(($range/2)))){  
			   for($i = $max_page - $range; $i <= $max_page; $i++){  
				  if($i==$paged){$class = "current number"; }else { $class = "number"; } 
				 echo "<a class='".$class."' href='" . get_pagenum_link($i). "'>$i</a>";   
			   }  
			 }  
			 // Somewhere in the middle  
			 elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){  
			   for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){  
				  if($i==$paged){$class = "current number"; }else { $class = "number"; } 
				 echo "<a class='".$class."' href='" . get_pagenum_link($i). "'>$i</a>";  
			   }  
			 }  
		}  
		// Less pages than the range, no sliding effect needed  
		else{  
		 for($i = 1; $i <= $max_page; $i++){  
		  if($i==$paged){$class = "current number"; }else { $class = "number"; } 
		   echo "<a class='".$class."' href='" . get_pagenum_link($i). "'>$i</a>";  
		 }  
		}  
		// Next page  
		next_posts_link(' > ');  
		// On the last page, don't put the Last page link  
		if($paged != $max_page){  
		 echo '<a class="last" href=" '. get_pagenum_link($max_page) .' "> >> </a>';  
		}  
	}  
}  	
function templatemela_posts_next_link_attributes($html){
	$html = str_replace('<a','<a class="next-post"',$html);
	return $html;
	}
	function templatemela_posts_previous_link_attributes($html){
	$html = str_replace('<a','<a class="prev-post"',$html);
	return $html;
	}
add_filter('next_post_link','templatemela_posts_next_link_attributes',10,1);
add_filter('previous_post_link','templatemela_posts_previous_link_attributes',10,1);
function templatemela_get_first_post_images($post_ID){
	global $post, $posts;
	$first_img_src = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	if (isset($matches[1][0]))
	$first_img_src = $matches[1][0];
	if(empty($first_img_src)){ 
		return 0;
	}
	return $first_img_src;
}
function templatemela_print_images_thumb($src,$alttext, $width=200,$height=200,$align='left')
{	
	$src = mr_image_resize($src, $width, $height, true, $align, false);
	if( empty ( $src ) || $src == 'image_not_specified' ):
		$src = get_template_directory_uri()."/images/megnor/placeholder.png";
		$src = mr_image_resize($src, $width, $height, true, $align, false);
	endif;
	$return = '';
	$return .= '<img src="'.$src.'"';
	$return .= " title='$alttext' alt='$alttext' width='$width' height='$height' />";	
	echo $return;
}
function templatemela_excerpt($limit) 
{
      $excerpt = explode(' ', templatemela_strip_images(strip_tags(get_the_excerpt())), $limit);
      if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).'&nbsp;.<div class="read-more"><a class="read-more-link" href="'.get_permalink().'">Read More</a></div>';
      } else {
        $excerpt = implode(" ",$excerpt);
      } 
      $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
      return $excerpt;
}
function templatemela_excerpt_blog($limit) 
{
      $excerpt = explode(' ', templatemela_strip_images(strip_tags(get_the_excerpt())), $limit);
      if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).'&nbsp;.<div class="read-more"><a class="read-more-link" href="'.get_permalink().'">Continue Reading</a></div>';
      } else {
        $excerpt = implode(" ",$excerpt);
      } 
      $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
      return $excerpt;
}
function templatemela_blog_post_excerpt($limit) 
{
      $excerpt = explode(' ', get_the_excerpt(), $limit);
      if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).'&nbsp;.<a class="read-more-link" href="'.get_permalink().'">Read More....</a>';
      } else {
        $excerpt = implode(" ",$excerpt);
      } 
      $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
      return $excerpt;
}
function templatemela_portfolio_excerpt($limit) 
{
    $contents = substr(templatemela_strip_images(strip_tags(get_the_excerpt())),0,$limit);	
	$excerpt = $contents; if (strlen($contents) >= $limit){ $excerpt .= '&hellip;'; }
  	return $excerpt;
}
if ( ! function_exists( 'tm_go_top' ) ) :
function tm_go_top(){ ?>
<div class="backtotop"><a style="display: none;" class="to_top" href="#"></a></div>
<?php } 
endif;
if ( ! function_exists( 'tm_favicon' ) ) :
function tm_favicon() {
	if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) {
		echo '<link rel="shortcut icon" type="image/png" href="'.get_template_directory_uri() .'/templatemela/favicon.ico" />';
	}
}
endif;
add_action( 'wp_head', 'tm_favicon' ); 
add_action( 'admin_head', 'tm_favicon' );
if ( ! function_exists( 'templatemela_strip_images' ) ) :
function templatemela_strip_images($content){	
   $content = preg_replace('/<img[^>]+./','',$content);
   return preg_replace('/<\/?a[^>]*>/','',$content);
}
endif;
/**
 * Remove inline styles printed when the gallery shortcode is used.
 * Galleries are styled by the theme in TemplateMela's style.css. This is just
 * a simple filter call that tells WordPress to not use the default styles.
 */
add_filter( 'use_default_gallery_style', '__return_false' );
// Control Panel Tags Function Includes //
get_template_part('templatemela/controlpanel/tm_control_panel'); 
get_template_part('templatemela/admin/hook-functions'); 
get_template_part('templatemela/example');  
get_template_part('mr-image-resize');
//Adds woocommerce functions if active
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) :
	get_template_part('templatemela/woocommerce-functions');
endif;
add_action( 'get_header', 'templatemela_load_fonts' );
/**
 * Enqueue Templatemela Fonts
 */
function templatemela_load_fonts() {
    $fonts_url = '';
 
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'fashion-feast' );
	$roboto = _x( 'on', 'Roboto font: on or off', 'fashion-feast' );
	
	if ( 'off' !== $open_sans || 'off' !== $roboto) {
        $font_families = array();
 
        if ( 'off' !== $open_sans ) {
            $font_families[] = 'Open Sans:400,600,700';
        }
 			
		if ( 'off' !== $roboto ) {
            $font_families[] = 'Roboto:400,500,700,900';					
        }
		
		$query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, '//fonts.googleapis.com/css' );
    } 
    return esc_url_raw( $fonts_url );
}
/*
Enqueue scripts and styles.
*/
function google_fonts() {
    wp_enqueue_style( 'google_fonts', templatemela_load_fonts(), array(), '1.0.0' );
}
add_action( 'get_header', 'google_fonts' );
/**
 * Enqueue Templatemela Styles
 */
if ( ! function_exists( 'templatemela_load_styles' ) ) :
function templatemela_load_styles() {
	wp_enqueue_style('css_isotope', get_template_directory_uri() . '/css/isotop-port.css');
	wp_enqueue_style('custom', get_template_directory_uri() . '/css/megnor/custom.css');
	wp_enqueue_style('owl.carousel', get_template_directory_uri() . '/css/megnor/owl.carousel.css');	
	wp_enqueue_style('shadowbox', get_template_directory_uri() . '/css/megnor/shadowbox.css');
	wp_enqueue_style('shortcode_style', get_template_directory_uri() . '/css/megnor/shortcode_style.css');
	wp_enqueue_style('tm-css-flexslider', get_template_directory_uri() . '/css/megnor/tm_flexslider.css');
	//Adds front end control panel css
	if(get_option('tmoption_control_panel') == 'yes'):
		wp_enqueue_style('tm_style', get_template_directory_uri() . '/css/megnor/tm-style.css');
	endif; 
	//Adds wocommerce style
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) :
		wp_enqueue_style('templatelema_woocommerce_css', get_template_directory_uri() . '/css/megnor/woocommerce.css');
	endif;
}
endif;
add_action('get_header', 'templatemela_load_styles');
/**
 * Enqueue Templatemela Scripts
 */
if ( ! function_exists( 'templatemela_load_scripts' ) ) :
function templatemela_load_scripts() {	
	wp_enqueue_script( 'jquery_jqtransform', get_template_directory_uri() . '/js/megnor/jquery.jqtransform.js', array(), '', true);
	wp_enqueue_script( 'jquery_jqtransform_script', get_template_directory_uri() . '/js/megnor/jquery.jqtransform.script.js', array(), '', true);
	wp_enqueue_script( 'jquery_custom_script', get_template_directory_uri() . '/js/megnor/jquery.custom.min.js', array(), '', true);
	wp_enqueue_script( 'jquery_isotope', get_template_directory_uri() . '/js/jquery.isotope.min.js', array(), '', true);
	wp_enqueue_script( 'jquery_megnor', get_template_directory_uri() . '/js/megnor/megnor.min.js', array(), '', true);
	wp_enqueue_script( 'jquery_carousel', get_template_directory_uri() . '/js/megnor/carousel.min.js', array(), '', true);
	wp_enqueue_script( 'jquery_easypiechart', get_template_directory_uri() . '/js/megnor/jquery.easypiechart.min.js', array(), '', false);
	wp_enqueue_script( 'jquery_custom', get_stylesheet_directory_uri() . '/js/megnor/custom.js', array(), '', false);
	wp_enqueue_script( 'jquery_owlcarousel', get_template_directory_uri() . '/js/megnor/owl.carousel.min.js', array(), '', false);
	wp_enqueue_script( 'jquery_formalize', get_template_directory_uri() . '/js/megnor/jquery.formalize.min.js', array(), '', false);
	wp_enqueue_script( 'jquery_respond', get_template_directory_uri() . '/js/megnor/respond.min.js', array(), '', false);
	wp_enqueue_script( 'jquery_validate', get_template_directory_uri() . '/js/megnor/jquery.validate.js', array(), '', false);
	wp_enqueue_script( 'jquery_shadowbox', get_template_directory_uri() . '/js/megnor/shadowbox.js', array(), '', false);
	wp_enqueue_script( 'jquery_flexslider', get_template_directory_uri() . '/js/megnor/jquery.flexslider.js', array(), '', false);
	wp_enqueue_script( 'jquery_waypoints', get_template_directory_uri() . '/js/megnor/waypoints.min.js', array(), '', false);
	wp_enqueue_script( 'jquery_megamenu', get_template_directory_uri() . '/js/megnor/jquery.megamenu.js', array(), '', false);	
	wp_enqueue_script( 'easyResponsiveTabs', get_template_directory_uri() . '/js/megnor/easyResponsiveTabs.js', array(), '', true);
	wp_enqueue_script( 'jtree_min', get_template_directory_uri() . '/js/megnor/jquery.treeview.js', array(), '', true);
	wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/js/megnor/modernizr.custom.js', array(), '', true);	
	wp_enqueue_script( 'jquery_parallax', get_template_directory_uri() . '/js/megnor/parallex.js', array(), '', true);	
	
?>  
<!--[if lt IE 9]>
	<?php wp_enqueue_script( 'html5', get_template_directory_uri() . '/js/html5.js', array(), '', true); ?>
	<![endif]-->
<?php }
endif;
add_action( 'wp_enqueue_scripts', 'templatemela_load_scripts' );
/**
 * Enqueue Templatemela Control Panel Scripts
 */
if ( ! function_exists( 'templatemela_load_controlpanel_script' ) ) :
function templatemela_load_controlpanel_script() {		
	if(get_option('tmoption_control_panel') == 'yes') : ?>
<script type="text/javascript">
			var tm_theme_path = "<?php echo get_template_directory_uri() ?>";			
		</script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/megnor/colorpicker/colorpicker.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/megnor/colorpicker/jquery.cookie.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/megnor/colorpicker/pscript.js"></script>
<?php	
	endif; 
}
endif;
add_action( 'wp_footer', 'templatemela_load_controlpanel_script' );
if ( ! function_exists( 'templatemela_breadcrumbs' ) ) :
function templatemela_breadcrumbs() { ?>
<div class="breadcrumbs">
  <?php if ( function_exists('yoast_breadcrumb') ) { ?>
  <?php yoast_breadcrumb('<p id="breadcrumbs">','</p>'); ?>
  <?php } ?>
</div>
<?php }
endif;
function templatemela_search_form( $form ) {
    $form = '<form role="search" method="get" id="searchform" class="search-form" action="' . home_url( '/' ) . '" >
    <div><label class="screen-reader-text" for="s">' . __( 'Search for:', 'fashion-feast' ) . '</label>
    <input class="search-field" type="text" value="' . get_search_query() . '" name="s" id="s" />
    <input class="search-submit" type="submit" id="searchsubmit" value="'. __( 'Go', 'fashion-feast' ) .'" />
    </div>
    </form>';
    return $form;
}
add_filter( 'get_search_form', 'templatemela_search_form' );
if ( ! function_exists( 'templatemela_comment' ) ) :
/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own templatemela_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 */
function templatemela_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
		// Display trackbacks differently than normal comments.
	?>
<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
  <p>
    <?php _e( 'Pingback:', 'fashion-feast' ); ?>
    <?php comment_author_link(); ?>
    <?php edit_comment_link( __( '(Edit)', 'fashion-feast' ), '<span class="edit-link">', '</span>' ); ?>
  </p>
</li>
<?php
			break;
		default :
		// Proceed with normal comments.
		global $post;
	?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
  <div id="comment-<?php comment_ID(); ?>" class="comment-body">
    <div class="alignleft"> <?php echo get_avatar( $comment, 48 ); ?> </div>
    <div class="author-content">
      <h6><?php echo $comment->comment_author; ?></h6>
      <?php edit_comment_link( __( 'Edit', 'fashion-feast' ), ' ' ); ?>
      <div class="clearfix"></div>
      <abbr class="published" title=""><?php printf( __( '%1$s at %2$s', 'fashion-feast' ), get_comment_date(),  get_comment_time() ); ?></abbr> </div>
    <div class="comment-content">
      <?php comment_text(); ?>
      <div class="reply">
        <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
      </div>
    </div>
    <!--<div class="comment-author vcard">
			<?php //echo get_avatar( $comment, 40 ); ?>
			<?php //printf( __( '%s <span class="says">says:</span>', 'fashion-feast' ), sprintf( '<cite class="fn">%s</cite>', get_comment_author_link() ) ); ?>
		</div><!-- .comment-author .vcard -->
    <?php if ( $comment->comment_approved == '0' ) : ?>
    <em class="comment-awaiting-moderation">
    <?php _e( 'Your comment is awaiting moderation.', 'fashion-feast' ); ?>
    </em> <br />
    <?php endif; ?>
  </div>
  <!-- #comment-##  -->
</li>
<?php
		break;
	endswitch; // end comment_type check
}
endif;
if ( ! function_exists( 'templatemela_entry_meta' ) ) :
/**
 * Print HTML with meta information for current post: categories, tags, permalink, author, and date.
 *
 * Create your own templatemela_entry_meta() to override in a child theme.
 *
 * @since Templatemela 1.0
 *
 * @return void
 */
function templatemela_entry_meta() {
}
endif;
if ( ! function_exists( 'templatemela_get_topbar_contact' ) ) :
function templatemela_get_topbar_contact() {
	$tmoption_topbar_address = get_option('tmoption_topbar_address');
	$tmoption_topbar_phone = get_option('tmoption_topbar_phone');
	$tmoption_topbar_email = get_option('tmoption_topbar_email');
	$tmoption_topbar_email_link = get_option('tmoption_topbar_email_link');
	$output = '';
	$output .= '<div class="topbar-contact">';
		if (!empty($tmoption_topbar_address))
		$output .= '<div class="address-content content"><i class="fa fa-map-marker"></i><span class="contact-address">'.$tmoption_topbar_address.'</span></div>';
		if (!empty($tmoption_topbar_phone))
		$output .= '<div class="phone-content content"><i class="fa fa-phone"></i><span class="contact-phone">'.$tmoption_topbar_phone.'</span></div>';
		if (!empty($tmoption_topbar_email)):
		$output .= '<div class="email-content content"><i class="fa fa-envelope"></i><span class="contact-email">';
			if (!empty($tmoption_topbar_email_link)):
				$output .= '<a href="'.$tmoption_topbar_email_link.'">'.$tmoption_topbar_email.'</a>';
			else: 
				$tmoption_topbar_email;
			endif;
		$output .= '</span></div>';
		endif;
	$output .= '</div>';
	echo $output;
}
endif;
if ( ! function_exists( 'templatemela_get_topbar_banner' ) ) :
function templatemela_get_topbar_banner() {	
	$tmoption_custom_text1 = get_option('tmoption_custom_text1');
	$tmoption_custom_text1_desc = get_option('tmoption_custom_text1_desc');
	$tmoption_custom_text2 = get_option('tmoption_custom_text2');
	$tmoption_custom_text2_desc = get_option('tmoption_custom_text2_desc');
	$tmoption_custom_text3 = get_option('tmoption_custom_text3');
	$tmoption_custom_text3_desc = get_option('tmoption_custom_text3_desc');
	$output = '';
	$output .= '<div class="top-banner-inner container">';
	$output .= '<ul class="top-banner-container">';
		if (!empty($tmoption_custom_text1)):
		$output .= '<li class="content1 content"><div class="content-inner"><i class="fa fa-truck"></i><div class="cms-title">'.$tmoption_custom_text1.'</div> <div class="cms-desc">'.$tmoption_custom_text1_desc.'</div></div></li>';	
		endif;
		if (!empty($tmoption_custom_text2)):
		$output .= '<li class="content2 content"><div class="content-inner"><i class="fa fa-retweet"></i><div class="cms-title">'.$tmoption_custom_text2.'</div> <div class="cms-desc">'.$tmoption_custom_text2_desc.'</div></div></li>';	
		endif;
		if (!empty($tmoption_custom_text3)):
		$output .= '<li class="content3 content"><div class="content-inner"><i class="fa fa-gift"></i><div class="cms-title">'.$tmoption_custom_text3.'</div> <div class="cms-desc">'.$tmoption_custom_text3_desc.'</div></div></li>';				
		endif;	
	$output .= '</ul>';	
	$output .= '</div>';
	echo $output;
}
endif;
if ( ! function_exists( 'templatemela_get_topbar_callus' ) ) :
function templatemela_get_topbar_callus() {
	$tmoption_topbar_phone_text = get_option('tmoption_topbar_phone_text');
	$tmoption_topbar_phone = get_option('tmoption_topbar_phone');
	$output = '';
	$output .= '<div class="header-contactus">';
		if (!empty($tmoption_topbar_phone_text))
		$output .= '<div class="call-text">'.$tmoption_topbar_phone_text .'</div>';
		if (!empty($tmoption_topbar_phone))
		$output .= '<div class="contact-phone">'.$tmoption_topbar_phone.'</div>';
	$output .= '</div>';
	echo $output;
}
endif;
if ( ! function_exists( 'templatemela_get_topbar_social' ) ) :
function templatemela_get_topbar_social() {
	
	$tmoption_topbar_twitter =  get_option('tmoption_topbar_twitter');
	$tmoption_topbar_facebook = get_option('tmoption_topbar_facebook');
	$tmoption_topbar_google_plus = get_option('tmoption_topbar_google_plus');
	$tmoption_topbar_linkedin = get_option('tmoption_topbar_linkedin');
	$tmoption_topbar_youtube = get_option('tmoption_topbar_youtube');
	$tmoption_topbar_rss = get_option('tmoption_topbar_rss');
	$tmoption_topbar_pinterest = get_option('tmoption_topbar_pinterest');
	$tmoption_topbar_skype = get_option('tmoption_topbar_skype');
	$output = '';
	$output .= '<div class="res-icon"></div>';
	$output .= '<div class="topbar-social">';
		if (!empty($tmoption_topbar_twitter))
		$output .= '<div class="social-twitter content"><a href="'.$tmoption_topbar_twitter.'" target="_Blank"><i class="fa fa-twitter"></i></a></div>';
		if (!empty($tmoption_topbar_facebook))
		$output .= '<div class="social-facebook content"><a href="'.$tmoption_topbar_facebook.'" target="_Blank"><i class="fa fa-facebook"></i></a></div>';
		if (!empty($tmoption_topbar_google_plus))
		$output .= '<div class="social-google-plus content"><a href="'.$tmoption_topbar_google_plus.'" target="_Blank"><i class="fa fa-google-plus"></i></a></div>';
		if (!empty($tmoption_topbar_linkedin))
		$output .= '<div class="social-linkedin content"><a href="'.$tmoption_topbar_linkedin.'" target="_Blank"><i class="fa fa-linkedin"></i></a></div>';
		if (!empty($tmoption_topbar_youtube))
		$output .= '<div class="social-youtube content"><a href="'.$tmoption_topbar_youtube.'" target="_Blank"><i class="fa fa-youtube"></i></a></div>';
		if (!empty($tmoption_topbar_rss))
		$output .= '<div class="social-rss content"><a href="'.$tmoption_topbar_rss.'" target="_Blank"><i class="fa fa-rss"></i></a></div>';
		if (!empty($tmoption_topbar_pinterest))
		$output .= '<div class="social-pinterest content"><a href="'.$tmoption_topbar_pinterest.'" target="_Blank"><i class="fa fa-pinterest"></i></a></div>';
		if (!empty($tmoption_topbar_skype))
		$output .= '<div class="social-skype content"><a href="'.$tmoption_topbar_skype.'" target="_Blank"><i class="fa fa-skype"></i></a></div>';
	$output .= '</div>';
	echo $output;	
}
endif;
if ( ! function_exists( 'templatemela_sticky_post' ) ) :
function templatemela_sticky_post() {
	if ( is_sticky() && is_home() && ! is_paged() )
		echo '<span class="featured-post">' . __( 'Sticky', 'fashion-feast' ) . '</span>';
}
endif;
if ( ! function_exists( 'templatemela_categories_links' ) ) :
function templatemela_categories_links() {
	// Translators: used between list items, there is a space after the comma.
	$categories_list = get_the_category_list( __( ', ', 'fashion-feast' ) );
	if ( $categories_list ) {
		echo '<span class="categories-links"><i class="fa fa-folder-o"></i>' . $categories_list . '</span>';
	}
}
endif;
if ( ! function_exists( 'templatemela_tags_links' ) ) :
function templatemela_tags_links() {
	// Translators: used between list items, there is a space after the comma.
	$tag_list = get_the_tag_list( '', __( ', ', 'fashion-feast' ) );
	if ( $tag_list ) {
		echo '<span class="tags-links"><i class="fa fa-tags"></i>' . $tag_list . '</span>';
	}
}
endif;
if ( ! function_exists( 'templatemela_author_link' ) ) :
function templatemela_author_link() {
	// Post author
	if ( 'post' == get_post_type() ) {
		printf( '<span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_attr( sprintf( __( 'View all posts by %s', 'fashion-feast' ), get_the_author() ) ),
			get_the_author()
		);
	}
}
endif;
if ( ! function_exists( 'templatemela_comments_link' ) ) :
function templatemela_comments_link() {
	//comments open
	if ( comments_open() && ! is_single() ) : ?>
<span class="comments-link"> <i class="fa fa-comment"></i>
<?php comments_popup_link( __( 'Leave a Comment', 'fashion-feast' ), __( '1 Comment', 'fashion-feast' ), __( '% Comments', 'fashion-feast' ) ); ?>
</span>
<?php endif; 
}
endif;
if ( ! function_exists( 'templatemela_entry_date' ) ) :
/**
 * Print HTML with date information for current post.
 *
 * Create your own templatemela_entry_date() to override in a child theme.
 *
 * @since Templatemela 1.0
 *
 * @param boolean $echo (optional) Whether to echo the date. Default true.
 * @return string The HTML-formatted post date.
 */
function templatemela_entry_date( $echo = true ) {
	if ( has_post_format( array( 'chat', 'status' ) ) )
		$format_prefix = _x( '%1$s on %2$s', '1: post format name. 2: date', 'fashion-feast' );
	else
		$format_prefix = '%2$s';
	$date = sprintf( '<span class="date"><a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a></span>',
		esc_url( get_permalink() ),
		esc_attr( sprintf( __( 'Permalink to %s', 'fashion-feast' ), the_title_attribute( 'echo=0' ) ) ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( sprintf( $format_prefix, get_post_format_string( get_post_format() ), get_the_date() ) )
	);
	if ( $echo )
		echo $date;
	return $date;
}
endif;
if ( ! function_exists( 'tm_post_entry_date' ) ) :
function tm_post_entry_date( ) {
	$date = get_the_date();	
	$day = date("j", strtotime($date) );
	$month = date("M", strtotime($date) );
	$date = '<div class="entry-date"><div class="day"><i class="fa fa-clock-o"></i>'.$day.' '.$month.'</div></div>';
	echo $date;
	return $date;
}
endif;
if ( ! function_exists( 'templatemela_the_attached_image' ) ) :
/**
 * Print the attached image with a link to the next attached image.
 *
 * @since Templatemela 1.0
 *
 * @return void
 */
function templatemela_the_attached_image() {
	/**
	 * Filter the image attachment size to use.
	 *
	 * @since Templatemela 1.0
	 *
	 * @param array $size {
	 *     @type int The attachment height in pixels.
	 *     @type int The attachment width in pixels.
	 * }
	 */
	$attachment_size     = apply_filters( 'templatemela_attachment_size', array( 724, 724 ) );
	$next_attachment_url = wp_get_attachment_url();
	$post                = get_post();
	/*
	 * Grab the IDs of all the image attachments in a gallery so we can get the URL
	 * of the next adjacent image in a gallery, or the first image (if we're
	 * looking at the last image in a gallery), or, in a gallery of one, just the
	 * link to that image file.
	 */
	$attachment_ids = get_posts( array(
		'post_parent'    => $post->post_parent,
		'fields'         => 'ids',
		'numberposts'    => -1,
		'post_status'    => 'inherit',
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'order'          => 'ASC',
		'orderby'        => 'menu_order ID'
	) );
	// If there is more than 1 attachment in a gallery...
	if ( count( $attachment_ids ) > 1 ) {
		foreach ( $attachment_ids as $attachment_id ) {
			if ( $attachment_id == $post->ID ) {
				$next_id = current( $attachment_ids );
				break;
			}
		}
		// get the URL of the next image attachment...
		if ( $next_id )
			$next_attachment_url = get_attachment_link( $next_id );
		// or get the URL of the first image attachment.
		else
			$next_attachment_url = get_attachment_link( array_shift( $attachment_ids ) );
	}
	printf( '<a href="%1$s" title="%2$s" rel="attachment">%3$s</a>',
		esc_url( $next_attachment_url ),
		the_title_attribute( array( 'echo' => false ) ),
		wp_get_attachment_image( $post->ID, $attachment_size )
	);
}
endif;
if ( ! function_exists( 'tm_posts_short_description' ) ) :
function tm_posts_short_description() {
	$tm_posts_short_description = get_post_meta(get_the_ID(), 'tm_posts_short_description', true);
	if(empty($tm_posts_short_description))
		$tm_posts_short_description = templatemela_excerpt(75);
	return $tm_posts_short_description;
}
endif;
if ( ! function_exists( 'tm_posts_short_description_blog' ) ) :
function tm_posts_short_description_blog() {
	$tm_posts_short_description = get_post_meta(get_the_ID(), 'tm_posts_short_description', true);
	if(empty($tm_posts_short_description))
		$tm_posts_short_description = templatemela_excerpt_blog(75);
	return $tm_posts_short_description;
}
endif;
if ( ! function_exists( 'tm_posts_show_thumbnail' ) ) :
function tm_posts_show_thumbnail() {
	$tm_posts_show_thumbnail = get_post_meta(get_the_ID(), 'tm_posts_show_thumbnail', true);
	if(empty($tm_posts_show_thumbnail))
		$tm_posts_show_thumbnail = '';
	return $tm_posts_show_thumbnail;
}
endif;
if ( ! function_exists( 'tm_page_layout' ) ) :
function tm_page_layout() {
	$page_layout_class = '';
	global $wp_query;	
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	if(is_shop()):
		$page_id = woocommerce_get_page_id('shop');
	else:
		$page_id = $wp_query->get_queried_object_id();
	endif;
	}else{
		$page_id = $wp_query->get_queried_object_id();
	}
	$tm_page_layout = get_post_meta($page_id, 'tm_page_layout', true);
	if(empty($tm_page_layout))
		$tm_page_layout = '';
		
	if($tm_page_layout == "box"):
		$page_layout_class = "box-page";
	elseif($tm_page_layout == "wide"):
		$page_layout_class = "wide-page";
	endif;
	return $page_layout_class;
}
endif;
if ( ! function_exists( 'tm_sidebar_position' ) ) :
function tm_sidebar_position() {
  $sidebar_class = '';
  global $wp_query;  
  if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
  if(is_shop()):
    $page_id = woocommerce_get_page_id('shop');
  else:
    $page_id = $wp_query->get_queried_object_id();
  endif;
  }else{
    $page_id = $wp_query->get_queried_object_id();
  }
  $tm_sidebar_position = get_post_meta($page_id, 'tm_sidebar_position', true);
  if(empty($tm_sidebar_position))
    $tm_sidebar_position = '';
    
  if($tm_sidebar_position == "left"):
    $sidebar_class = "left-sidebar";
  elseif($tm_sidebar_position == "right"):
    $sidebar_class = "right-sidebar";
  elseif($tm_sidebar_position == "disabled"):
    $sidebar_class = "full-width";
  endif;
  return $sidebar_class;
}
endif;
if ( ! function_exists( 'tm_blog_box_display' ) ) :
function tm_blog_box_display() {
	$main_container = '';
	$tm_blog_box_display = get_post_meta(get_the_ID(), 'tm_blog_box_display', true);
	if(empty($tm_blog_box_display))
		$tm_blog_box_display = '';
	if($tm_blog_box_display == 'masonry'):
		$main_container = 'masonry';
	elseif($tm_blog_box_display == 'grid'):
		$main_container = 'grid';
	endif;
	return $main_container;
}
endif;
if ( ! function_exists( 'tm_blog_box_columns_class' ) ) :
function tm_blog_box_columns_class() {
	$columns_class = '';
	$tm_blog_box_columns = get_post_meta(get_the_ID(), 'tm_blog_box_columns', true);
	if(empty($tm_blog_box_columns))
		$tm_blog_box_columns = '';
	if($tm_blog_box_columns == 'two'):
		$columns_class = 'two-col';
	elseif($tm_blog_box_columns == 'three'):
		$columns_class = 'three-col';
	elseif($tm_blog_box_columns == 'four'):
		$columns_class = 'four-col';
	endif;
	return $columns_class;
}
endif;
if ( ! function_exists( 'tm_blog_box_columns_number' ) ) :
function tm_blog_box_columns_number() {
	$columns_number = '';
	$tm_blog_box_columns = get_post_meta(get_the_ID(), 'tm_blog_box_columns', true);
	if(empty($tm_blog_box_columns))
		$tm_blog_box_columns = '';
	if($tm_blog_box_columns == 'two'):
		$columns_number = '2';
	elseif($tm_blog_box_columns == 'three'):
		$columns_number = '3';
	elseif($tm_blog_box_columns == 'four'):
		$columns_number = '4';
	endif;
	return $columns_number;
}
endif;
if ( ! function_exists( 'tm_blog_box_posts_per_page' ) ) :
function tm_blog_box_posts_per_page() {
	$tm_blog_box_posts_per_page = get_post_meta(get_the_ID(), 'tm_blog_box_posts_per_page', true);
	if(empty($tm_blog_box_posts_per_page))
		$tm_blog_box_posts_per_page = '';
	return $tm_blog_box_posts_per_page;
}
endif;
if ( ! function_exists( 'tm_blog_list_posts_per_page' ) ) :
function tm_blog_list_posts_per_page() {
	$tm_blog_list_posts_per_page = get_post_meta(get_the_ID(), 'tm_blog_list_posts_per_page', true);
	if(empty($tm_blog_list_posts_per_page))
		$tm_blog_list_posts_per_page = '';
	return $tm_blog_list_posts_per_page;
}
endif;
if ( ! function_exists( 'tm_blog_filter_columns_class' ) ) :
function tm_blog_filter_columns_class() {
	$columns_class = '';
	$tm_blog_filter_columns = get_post_meta(get_the_ID(), 'tm_blog_filter_columns', true);
	if(empty($tm_blog_filter_columns))
		$tm_blog_filter_columns = '';
	if($tm_blog_filter_columns == 'two'):
		$columns_class = 'two-col';
	elseif($tm_blog_filter_columns == 'three'):
		$columns_class = 'three-col';
	elseif($tm_blog_filter_columns == 'four'):
		$columns_class = 'four-col';
	endif;
	return $columns_class;
}
endif;
if ( ! function_exists( 'tm_blog_filter_columns_number' ) ) :
function tm_blog_filter_columns_number() {
	$columns_number = '';
	$tm_blog_filter_columns = get_post_meta(get_the_ID(), 'tm_blog_filter_columns', true);
	if(empty($tm_blog_filter_columns))
		$tm_blog_filter_columns = '';
	if($tm_blog_filter_columns == 'two'):
		$columns_number = '2';
	elseif($tm_blog_filter_columns == 'three'):
		$columns_number = '3';
	elseif($tm_blog_filter_columns == 'four'):
		$columns_number = '4';
	endif;
	return $columns_number;
}
endif;
if ( ! function_exists( 'tm_testimonial_box_posts_per_page' ) ) :
function tm_testimonial_box_posts_per_page() {
	$tm_testimonial_box_posts_per_page = get_post_meta(get_the_ID(), 'tm_testimonial_box_posts_per_page', true);
	if(empty($tm_testimonial_box_posts_per_page))
		$tm_testimonial_box_posts_per_page = '';
	return $tm_testimonial_box_posts_per_page;
}
endif;
if ( ! function_exists( 'tm_testimonial_list_posts_per_page' ) ) :
function tm_testimonial_list_posts_per_page() {
	$tm_testimonial_list_posts_per_page = get_post_meta(get_the_ID(), 'tm_testimonial_list_posts_per_page', true);
	if(empty($tm_testimonial_list_posts_per_page))
		$tm_testimonial_list_posts_per_page = '';
	return $tm_testimonial_list_posts_per_page;
}
endif;
if ( ! function_exists( 'tm_testimonial_box_columns_class' ) ) :
function tm_testimonial_box_columns_class() {
	$columns_class = '';
	$tm_testimonial_box_columns = get_post_meta(get_the_ID(), 'tm_testimonial_box_columns', true);
	if(empty($tm_testimonial_box_columns))
		$tm_testimonial_box_columns = '';
	if($tm_testimonial_box_columns == 'two'):
		$columns_class = 'two-col';
	elseif($tm_testimonial_box_columns == 'three'):
		$columns_class = 'three-col';
	elseif($tm_testimonial_box_columns == 'four'):
		$columns_class = 'four-col';
	endif;
	return $columns_class;
}
endif;
if ( ! function_exists( 'tm_testimonial_box_columns_number' ) ) :
function tm_testimonial_box_columns_number() {
	$columns_number = '';
	$tm_testimonial_box_columns = get_post_meta(get_the_ID(), 'tm_testimonial_box_columns', true);
	if(empty($tm_testimonial_box_columns))
		$tm_testimonial_box_columns = '';
	if($tm_testimonial_box_columns == 'two'):
		$columns_number = '2';
	elseif($tm_testimonial_box_columns == 'three'):
		$columns_number = '3';
	elseif($tm_testimonial_box_columns == 'four'):
		$columns_number = '4';
	endif;
	return $columns_number;
}
endif;
if ( ! function_exists( 'tm_staff_box_posts_per_page' ) ) :
function tm_staff_box_posts_per_page() {
	$tm_staff_box_posts_per_page = get_post_meta(get_the_ID(), 'tm_staff_box_posts_per_page', true);
	if(empty($tm_staff_box_posts_per_page))
		$tm_staff_box_posts_per_page = '';
	return $tm_staff_box_posts_per_page;
}
endif;
if ( ! function_exists( 'tm_staff_list_posts_per_page' ) ) :
function tm_staff_list_posts_per_page() {
	$tm_staff_list_posts_per_page = get_post_meta(get_the_ID(), 'tm_staff_list_posts_per_page', true);
	if(empty($tm_staff_list_posts_per_page))
		$tm_staff_list_posts_per_page = '';
	return $tm_staff_list_posts_per_page;
}
endif;
if ( ! function_exists( 'tm_staff_box_columns_class' ) ) :
function tm_staff_box_columns_class() {
	$columns_class = '';
	$tm_staff_box_columns = get_post_meta(get_the_ID(), 'tm_staff_box_columns', true);
	if(empty($tm_staff_box_columns))
		$tm_staff_box_columns = '';
	if($tm_staff_box_columns == 'two'):
		$columns_class = 'two-col';
	elseif($tm_staff_box_columns == 'three'):
		$columns_class = 'three-col';
	elseif($tm_staff_box_columns == 'four'):
		$columns_class = 'four-col';
	endif;
	$columns_class;
	return $columns_class;
}
endif;
if ( ! function_exists( 'tm_staff_box_columns_number' ) ) :
function tm_staff_box_columns_number() {
	$columns_number = '';
	$tm_staff_box_columns = get_post_meta(get_the_ID(), 'tm_staff_box_columns', true);
	if(empty($tm_staff_box_columns))
		$tm_staff_box_columns = '';
	if($tm_staff_box_columns == 'two'):
		$columns_number = '2';
	elseif($tm_staff_box_columns == 'three'):
		$columns_number = '3';
	elseif($tm_staff_box_columns == 'four'):
		$columns_number = '4';
	endif;
	return $columns_number;
}
endif;
if ( ! function_exists( 'tm_content_position' ) ) :
function tm_content_position() {
	$tm_content_position = get_post_meta(get_the_ID(), 'tm_content_position', true);
	if(empty($tm_content_position))
		$tm_content_position = '';
	return $tm_content_position;
}
endif;
if ( ! function_exists( 'templatemela_is_related_posts' ) ) :
function templatemela_is_related_posts() {
	$templatemela_is_related_posts = get_post_meta(get_the_ID(), 'tm_posts_show_related_posts', true);
	if(empty($templatemela_is_related_posts))
		$templatemela_is_related_posts = '';
	return $templatemela_is_related_posts;
}
endif;
if ( ! function_exists( 'templatemela_is_author_info' ) ) :
function templatemela_is_author_info() {
	$templatemela_is_author_info = get_post_meta(get_the_ID(), 'tm_posts_show_author_info', true);
	if(empty($templatemela_is_author_info))
		$templatemela_is_author_info = '';
	return $templatemela_is_author_info;
}
endif;
if ( ! function_exists( 'templatemela_shortcode_paging_nav' ) ) :
function templatemela_shortcode_paging_nav() {
	if ( $GLOBALS['wp_query']->max_num_pages > 1 ) {
	$paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$query_args   = array();
	$url_parts    = explode( '?', $pagenum_link );
	if ( isset( $url_parts[1] ) ) {
		wp_parse_str( $url_parts[1], $query_args );
	}
	$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
	$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';
	$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';
	// Set up paginated links.
	$links = paginate_links( array(
		'base'     => $pagenum_link,
		'format'   => $format,
		'total'    => $GLOBALS['wp_query']->max_num_pages,
		'current'  => $paged,
		'mid_size' => 1,
		'add_args' => array_map( 'urlencode', $query_args ),
		'prev_text' => __( '<i class="fa fa-angle-left"></i>', 'fashion-feast' ),
		'next_text' => __( '<i class="fa fa-angle-right"></i>', 'fashion-feast' ),
	) );
	$output = '';
	if ( $links ) :
	$output .= '<nav class="navigation paging-navigation" role="navigation">';
		$output .= '<div class="pagination loop-pagination">';
		$output .= $links;
		$output .= '</div>';
	$output .= '</nav>';
	endif; 
	}
	return $output;
}
endif;
if ( !defined( 'TEMPLATEMELA_THEME_DIR' ) ) {
	define( 'TEMPLATEMELA_THEME_DIR', get_template_directory() );
}
if ( !defined( 'TEMPLATEMELA_THEME_URI' ) ) {
	define( 'TEMPLATEMELA_THEME_URI', get_template_directory_uri() );
}
if ( !defined( 'TEMPLAETMELA_EXTENSIONS_DIR' ) ) {
	define( 'TEMPLAETMELA_EXTENSIONS_DIR', trailingslashit( TEMPLATEMELA_THEME_DIR ) . 'templatemela' );
}
if ( !defined( 'TEMPLATEMELA_EXTENSION_URI' ) ) {
	define( 'TEMPLATEMELA_EXTENSION_URI', trailingslashit( TEMPLATEMELA_THEME_URI ) . 'templatemela' );
}
if ( !defined( 'RWMB_URL' ) ) {
	define( 'RWMB_URL', trailingslashit( trailingslashit( TEMPLATEMELA_EXTENSION_URI ) . 'meta-box' ) );
}
if ( !defined( 'RWMB_DIR' ) ) {
	define( 'RWMB_DIR', trailingslashit( trailingslashit( TEMPLAETMELA_EXTENSIONS_DIR ) . 'meta-box' ) );
}
/* Start  Metabox */
// Include the meta box script
	echo get_template_part( '/templatemela/meta-box/meta-box' );
// define global metaboxes array
global $TM_META_BOXES;
$TM_META_BOXES = array();
// include metaboxes
$metaboxes = array(
	'metaboxes-post.php',
	'metaboxes-common.php',
	'metaboxes-page.php',
	'metaboxes-testimonial.php',
	'metaboxes-staff.php'
);
foreach ( $metaboxes as $metabox ) {
	require_once get_template_directory() . '/templatemela/tm-meta-boxes' . '/' . $metabox ;		
}
/**
 * Register meta boxes
 *
 * @return void
 */
add_action( 'admin_init', 'rw_register_meta_box' );
function rw_register_meta_box()
{
	// Make sure there's no errors when the plugin is deactivated or during upgrade
	if ( !class_exists( 'RW_Meta_Box' ) ) {
		return;
	}	
	global $TM_META_BOXES;	
	foreach ( $TM_META_BOXES as $meta_box ) {
		new RW_Meta_Box( $meta_box );
	}
}
/**
 * Localize meta boxes
 *
 * @return void
 */
function presscore_localize_meta_boxes() {
	global $TM_META_BOXES;
	$localized_meta_boxes = array();
	foreach ( $TM_META_BOXES as $meta_box ) {
		$localized_meta_boxes[ $meta_box['id'] ] = isset($meta_box['display_on'], $meta_box['display_on']['template']) ? (array) $meta_box['display_on']['template'] : array(); 
	}
	wp_localize_script( 'tm_metabox_script', 'tmMetaboxes', $localized_meta_boxes );
}
add_action( 'admin_enqueue_scripts', 'presscore_localize_meta_boxes', 15 );
/* End Metabox */
/* Woocommerce Product quickview Setting start */
echo get_template_part( '/templatemela/tm-product-quickview/main' );
if ( !defined( 'WML_URL' ) ) {
	define( 'WML_URL', trailingslashit( trailingslashit( TEMPLATEMELA_THEME_URI ) . 'templatemela/tm-product-quickview' ) );
}
if ( !defined( 'WML_DIR' ) ) {
	define( 'WML_DIR', trailingslashit( trailingslashit( TEMPLATEMELA_THEME_DIR ) . 'templatemela/tm_product_quickview' ) );
}
define( 'WML_JS_URL', trailingslashit( WML_URL . 'assets/js' ) );
define( 'WML_CSS_URL', trailingslashit( WML_URL . 'assets/css' ) );
/* Woocommerce Product quickview Setting end */
// Adds custom image height X width for small thumbnails
add_image_size( 'blog-posts-list', 918, 300, true );
add_image_size( 'small-thumb', 50, 50, true );
//Create HTML list of nav menu items and allow HTML tags.
class Description_Walker extends Walker_Nav_Menu { 
	function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		$classes = empty ( $item->classes ) ? array () : (array) $item->classes;	 
		$class_names = join(' ', apply_filters(	'nav_menu_css_class', array_filter( $classes ), $item ) );	 
		! empty ( $class_names ) and $class_names = ' class="'. esc_attr( $class_names ) . '"';
		// Build default menu items
		$output .= "<li id='menu-item-$item->ID' $class_names>";
		$attributes = '';	 
		! empty( $item->attr_title )
		and $attributes .= ' title="' . esc_attr( $item->attr_title ) .'"';
		! empty( $item->target )
		and $attributes .= ' target="' . esc_attr( $item->target ) .'"';
		! empty( $item->xfn )
		and $attributes .= ' rel="' . esc_attr( $item->xfn ) .'"';
		! empty( $item->url )
		and $attributes .= ' href="' . esc_attr( $item->url ) .'"';
		// Build the description (you may need to change the depth to 0, 1, or 2)
		$description = ( ! empty ( $item->description ) and 1 == $depth ) ? '<span class="nav_desc">'. $item->description . '</span>' : '';		 
		$title = apply_filters( 'the_title', $item->title, $item->ID );		 
		$item_output = $args->before . "<a $attributes>" . $args->link_before . $title . '</a> ' . $args->link_after . $description . $args->after;
		// Since $output is called by reference we don't need to return anything.
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args, $id  );
	}
} 
// Allow HTML descriptions in WordPress Menu
remove_filter( 'nav_menu_description', 'strip_tags' );
function templatemela_shop_body_classes( $classes ) {
if(isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] == 'left'){
	$classes[] = 'shop-left-sidebar '; 
	}elseif(isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] == 'right'){
	$classes[] = 'shop-right-sidebar '; 
	}elseif(isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] == 'full'){
	$classes[] = 'shop-full-width ';	
	}else{
	$classes[] = 'shop-left-sidebar' ;
}
	return $classes;
}
add_filter( 'body_class', 'templatemela_shop_body_classes' );
function is_blog () {
	global  $post;
	$posttype = get_post_type($post );
	return ( ((is_archive()) || (is_author()) ||  (is_home()) ||  (is_tag())) && ( $posttype == 'post')  ) ? true : false ;
}
/* Related Product settings */
function related_products_args( $args ) {
  	$no = get_option("tmoption_related_items");	
	$args['posts_per_page'] = $no; 
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'related_products_args' );
remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 20 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 20 );
if( ! function_exists( 'yith_wcwl_add_to_wishlist_in_shop' ) ){
    function yith_wcwl_add_to_wishlist_in_shop(){
        echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );
    }
}
add_action( 'woocommerce_before_shop_loop_item_title', 'yith_wcwl_add_to_wishlist_in_shop', 20 );
/*function woocommerce_details_tab_hook() {
	templatemela_get_widget('detais-tabs');    
}
add_action( 'woocommerce_single_product_summary', 'woocommerce_details_tab_hook', 50 );*/
/*	Product Navigation in shop page	 */
function tm_product_navigation()
{		
		global $post;
		$current_url = get_permalink( $post->ID );
		$next_text = '';
		$previous_text = '';		
		
		// Get the previous and next product links
		$previous_link = get_permalink(get_adjacent_post(false,'',false)); 
		$next_link = get_permalink(get_adjacent_post(false,'',true));
		
		// Create the two links provided the product exists
		if ( $next_link != $current_url ) {
				$next = "<a href='" . $next_link . "'>" . $next_text . "</a>";
			}
			if ( $previous_link != $current_url ) {
				$previous = "<a href='" . $previous_link . "'>" . $previous_text . "</a>";
		}
		
		// Create the two links provided the product exists
			if ( $next_link != $current_url ) {
				$next_text = get_adjacent_post(false,'',true)->post_title;
				$next = "<a href='" . $next_link . "'>" . $next_text . "</a>";
			} 
			if ( $previous_link != $current_url ) {
				$previous_text = get_adjacent_post(false,'',false)->post_title;
				$previous = "<a href='" . $previous_link . "'>" . $previous_text . "</a>";
			}
			
		// Create HTML Output
		$output  = '<div class="tm_product_nav_buttons">'; 
		if ( $previous != '' )
			$output .= '<span class="previous"> ' . $previous . '</span>';
		if ( $next != '' )
			$output .= '<span class="next">' . $next .'</span>';
		$output .= '</div>';
		
		// Display the final output
		echo $output;
}
add_action( 'woocommerce_single_product_summary', 'tm_product_navigation', 5 );
?>