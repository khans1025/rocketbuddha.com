var $k = jQuery.noConflict();
$k(function($) {
    $k('.cformselect').jqTransform();				
});